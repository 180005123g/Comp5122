<?php
// Heading
$_['heading_title']    = 'PDF Invoice Plus';
$_['heading_module']   = 'PDF Invoice Plus';

$_['text_ltr']         = 'LTR (left to right)';
$_['text_rtl']         = 'RTL (right to left)';

$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified \'PDF Invoice Plus\' module!';

$_['text_shipping_method']     = 'Shipping Method:';
$_['text_payment_method']      = 'Payment Method:';
$_['text_payment_address']     = 'Billing Address';
$_['text_shipping_address']    = 'Shipping Address';
$_['text_date_added']          = 'Date:';
$_['text_order_id']            = 'Order ID:';
$_['text_invoice_no']          = 'Invoice No.:';
$_['text_barcode']   			= 'BARCODE';
$_['text_qrcode']    			= 'QRCODE';
$_['text_nocode']    			= 'None';
$_['text_productname']			= 'Product Name';
$_['text_model']				= 'Model';
$_['text_sku']					= 'SKU';
$_['text_upc']					= 'UPC';
$_['text_ean']					= 'EAN';
$_['text_jan']					= 'JAN';
$_['text_isbn']					= 'ISBN';
$_['text_mpn']					= 'MPN';
$_['text_def_template']		    = 'Default Invoice Template';
$_['text_alt_template']			= 'Invoice Template with Weight and Dimension';
$_['text_dispatch']				= 'Dispatch Note / Packing List';

$_['text_paging'] = 'Page %s of %s';

$_['button_invoice']  = 'Download Invoice';

// Column
$_['column_total']             = 'Total';
$_['column_product']           = 'Product';
$_['column_image']             = 'Image';
$_['column_model']             = 'Model';
$_['column_quantity']          = 'Qty.';
$_['column_price']             = 'Price';

// Entry
$_['entry_attach']    = '<span title="Attach to order mail" data-toggle="tooltip">Attach Mail</span>';
$_['entry_barcode']   = '<span title="Add Barcode to Invoice" data-toggle="tooltip">Barcode Type</span>';
$_['entry_barcode_name']   = '<span title="Select field to be show in barcode/qrcode" data-toggle="tooltip">Field show in Barcode/QRcode</span>';
$_['entry_dimension']   = '<span title="Use Invoice Template complete with Weight and Dimension Information" data-toggle="tooltip">Weight and Dimension</span>';
$_['entry_template']   = '<span title="Please choose Invoice template - Default or Plus with Weight and Dimension Information" data-toggle="tooltip">Invoice Template</span>';
$_['entry_color']     = 'Color Theme';
$_['entry_complete']  = '<span title="Invoice only available if order status is complete" data-toggle="tooltip">Order Complete</span>';
$_['entry_direction'] = 'Text Direction';
$_['entry_download']  = '<span title="Add button to download invoice from order information page" data-toggle="tooltip">Customer Download</span>';
$_['entry_footer']    = 'Footer';
$_['entry_header']    = 'Header';
$_['entry_image']     = 'Product Image';
$_['entry_logo']      = 'Logo';
$_['entry_status']    = 'Status';
$_['button_preview']  = 'Preview PDF';
$_['entry_header_title']   = '<span title="Invoice Title(Default: INVOICE)" data-toggle="tooltip">Invoice Title</span>';
$_['entry_color']  = 'Header Background Color';
$_['entry_header_font']  = 'Header Font Type';
$_['entry_header_font_size']  = 'Header Font Size';
$_['entry_header_font_color']  = 'Header Font Color';
$_['entry_color_content']  = 'Content Background Color';
$_['entry_content_font']  = 'Content Font Type';
$_['entry_content_font_size']  = 'Content Font Size';
$_['entry_content_font_color']  = 'Content Font Color';
$_['entry_direction']  = 'Text Direction';
$_['entry_barcode_header']   = '<span title="Add Barcode to Invoice Header" data-toggle="tooltip">Barcode Type (Invoice Header)</span>';
$_['entry_barcode_header_name']   = '<span title="Select field to be show in barcode/qrcode (Invoice Header)" data-toggle="tooltip">Field show in Barcode/QRcode (Invoice Header)</span>';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify \'PDF Invoice Plus\' module!';

// Dimension
$_['column_weight']   = 'Weight';
$_['column_dimension']  = 'Dim.(LxWxH)';
$_['text_weight']       = '%s %s';
$_['text_dimension']    = '%s x %s x %s %s';
$_['column_total_wdq']   = 'Total Weight / Cubic Meter / Volumetric Weight / Quantity';
$_{'text_total_weight'}    = '%s %s';
$_{'text_total_dimension'} = '%s M3';
$_{'text_total_quantity'}  = '%s';
$_{'text_volumetric'}   = '%s Kg';
$_{'text_invoice_title'}   = 'INVOICE';

// Tabs
$_['tab_header']	= 'Template Setting';
$_['tab_barcode']	= 'Barcode Setting';
$_['tab_mail']	= 'General and Mail Setting';

// Barcode_Format
$_['text_bc1']    = 'CODE 39 - ANSI MH10.8M-1983 - USD-3 - 3 of 9';
$_['text_bc2']    = 'CODE 39 + CHECKSUM';
$_['text_bc3']    = 'CODE 39 EXTENDED';
$_['text_bc4']    = 'CODE 39 EXTENDED + CHECKSUM';
$_['text_bc5']    = 'CODE 93 - USS-93';
$_['text_bc6']    = 'Standard 2 of 5';
$_['text_bc7']    = 'Standard 2 of 5 + CHECKSUM';
$_['text_bc8']    = 'Interleaved 2 of 5';
$_['text_bc9']    = 'Interleaved 2 of 5 + CHECKSUM';
$_['text_bc10']    = 'CODE 128 AUTO';
$_['text_bc11']    = 'CODE 128 A';
$_['text_bc12']    = 'CODE 128 B';
$_['text_bc13']    = 'CODE 128 C';
$_['text_bc14']    = 'EAN 8';
$_['text_bc15']    = 'EAN 13';
$_['text_bc16']    = 'UPC-A';
$_['text_bc17']    = 'UPC-E';
$_['text_bc18']    = '5-Digits UPC-Based Extension';
$_['text_bc19']    = '2-Digits UPC-Based Extension';
$_['text_bc20']    = 'MSI';
$_['text_bc21']    = 'MSI + CHECKSUM (module 11)';
$_['text_bc22']    = 'CODABAR';
$_['text_bc23']    = 'CODE 11';
$_['text_bc24']    = 'PHARMACODE';
$_['text_bc25']    = 'PHARMACODE TWO-TRACKS';
$_['text_bc26']    = 'IMB - Intelligent Mail Barcode - Onecode - USPS-B-3200';
$_['text_bc27']    = 'POSTNET';
$_['text_bc28']    = 'PLANET';
$_['text_bc29']    = 'RMS4CC (Royal Mail 4-state Customer Code) - CBC (Customer Bar Code)';
$_['entry_barcode_format']    = 'Standard Barcode Format';

// QRcode_Format
$_['text_qr1']    =  'QRCODE,L : QR-CODE Low error correction';
$_['text_qr2']    =  'QRCODE,M : QR-CODE Medium error correction';
$_['text_qr3']    =  'QRCODE,Q : QR-CODE Better error correction';
$_['text_qr4']    =  'QRCODE,H : QR-CODE Best error correction';
$_['text_qr5']    =  'DATAMATRIX (ISO/IEC 16022:2006)';
$_['entry_qrcode_format']    = 'Standard QRcode Format';