<?php
$_['text_tfa']                 = 'Two Factor Authentication';