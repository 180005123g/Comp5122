<?php
$_['entry_tfa']                 = 'Two Factor Authentication';