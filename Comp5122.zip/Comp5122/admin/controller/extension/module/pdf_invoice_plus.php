<?php
class ControllerExtensionModulePdfInvoicePlus extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/pdf_invoice_plus');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_pdf_invoice_plus', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/module/pdf_invoice_plus', 'user_token=' . $this->session->data['user_token'], true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_module'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/pdf_invoice_plus', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/module/pdf_invoice_plus', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'], true);

		$this->load->model('tool/image');
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		
		$cwd = getcwd();
        $dir = (strcmp(VERSION,'3.0.0.0')>=0) ? 'library' : 'tcpdf';
        chdir( DIR_SYSTEM.$dir );
        require_once( DIR_SYSTEM.'library/PdfInvoicePlus.php' );
        $pdf_invoice_plus = new PdfInvoicePlus;
        chdir( $cwd );
        
        //load post/config/default into form
        foreach ($pdf_invoice_plus->default_data as $k => $v) {
            if (isset($this->request->post[$k])) {
                $data[$k] = $this->request->post[$k];
            } else if ($this->config->get($k) !== null) {
                $data[$k] = $this->config->get($k);
            } else {
                $data[$k] = $v;
            }
        }

		if (isset($this->request->post['module_pdf_invoice_plus_logo'])) {
			$data['module_pdf_invoice_plus_logo'] = $this->request->post['module_pdf_invoice_plus_logo'];
		} else {
			$data['module_pdf_invoice_plus_logo'] = $this->config->get('module_pdf_invoice_plus_logo');
		}
		
		if (isset($this->request->post['module_pdf_invoice_plus_barcode_image'])) {
			$data['module_pdf_invoice_plus_barcode_image'] = $this->request->post['module_pdf_invoice_plus_barcode_image'];
		} else {
			$data['module_pdf_invoice_plus_barcode_image'] = $this->config->get('module_pdf_invoice_plus_barcode_image');
		}
				
		if (isset($this->request->post['module_pdf_invoice_plus_qrcode_image'])) {
			$data['module_pdf_invoice_plus_qrcode_image'] = $this->request->post['module_pdf_invoice_plus_qrcode_image'];
		} else {
			$data['module_pdf_invoice_plus_qrcode_image'] = $this->config->get('module_pdf_invoice_plus_qrcode_image');
		}
		
		if (isset($this->request->post['module_pdf_invoice_plus_logo']) && is_file(DIR_IMAGE . $this->request->post['module_pdf_invoice_plus_logo'])) {
			$data['logo_thumb'] = $this->model_tool_image->resize($this->request->post['module_pdf_invoice_plus_logo'], 100, 100);
		} elseif ($this->config->get('module_pdf_invoice_plus_logo') && is_file(DIR_IMAGE . $this->config->get('module_pdf_invoice_plus_logo'))) {
			$data['logo_thumb'] = $this->model_tool_image->resize($this->config->get('module_pdf_invoice_plus_logo'), 100, 100);
		} else {
			$data['logo_thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		foreach ($data['languages'] as $language) {
			$data['module_pdf_invoice_plus_preview'][$language['language_id']] = $this->url->link('extension/module/pdf_invoice_plus/preview', 'user_token=' . $this->session->data['user_token'] . '&language_id=' . $language['language_id'], true);

			if (isset($this->request->post['module_pdf_invoice_plus_header_' . $language['language_id']])) {
				$data['module_pdf_invoice_plus_header_' . $language['language_id']] = $this->request->post['module_pdf_invoice_plus_header_' . $language['language_id']];
			} else {
				$data['module_pdf_invoice_plus_header_' . $language['language_id']] = $this->config->get('module_pdf_invoice_plus_header_' . $language['language_id']);
			}

			if (isset($this->request->post['module_pdf_invoice_plus_footer_' . $language['language_id']])) {
				$data['module_pdf_invoice_plus_footer_' . $language['language_id']] = $this->request->post['module_pdf_invoice_plus_footer_' . $language['language_id']];
			} else {
				$data['module_pdf_invoice_plus_footer_' . $language['language_id']] = $this->config->get('module_pdf_invoice_plus_footer_' . $language['language_id']);
			}

			if (isset($this->request->post['module_pdf_invoice_plus_rtl_' . $language['language_id']])) {
				$data['module_pdf_invoice_plus_rtl_' . $language['language_id']] = $this->request->post['module_pdf_invoice_plus_rtl_' . $language['language_id']];
			} else {
				$data['module_pdf_invoice_plus_rtl_' . $language['language_id']] = $this->config->get('module_pdf_invoice_plus_rtl_' . $language['language_id']);
			}
		}

		$this->document->addStyle('view/javascript/bootstrap/css/bootstrap-colorpicker.min.css');
		$this->document->addScript('view/javascript/bootstrap/js/bootstrap-colorpicker.min.js');
		$this->document->addScript('view/javascript/bootstrap/js/bootstrap-checkbox.min.js');

		$this->document->addStyle('view/javascript/summernote/summernote.css');
		$this->document->addScript('view/javascript/summernote/summernote.js');
		$this->document->addScript('view/javascript/summernote/opencart.js');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		// Load core fonts
        if (extension_loaded('mbstring')) {
            $core_fonts_dir = (strcmp(VERSION,'3.0.0.0')>=0) ? DIR_SYSTEM.'library/tcpdf/fonts' : DIR_SYSTEM.'tcpdf/fonts';
        }
        else {
            $core_fonts_dir = (strcmp(VERSION,'3.0.0.0')>=0) ? DIR_SYSTEM.'library/tcpdf/fonts' : DIR_SYSTEM.'tcpdf/fonts';
        }
        $core_font_files = array();
        $path = array($core_fonts_dir . '/*');
        while (count($path) != 0) {
            $next = array_shift($path);
            foreach ((array)glob($next) as $core_font_file) {
                if (is_dir($core_font_file)) {
                    $path[] = $core_font_file . '/*';
                }
                $core_font_files[] = $core_font_file;
            }
        }
        $core_fonts = array();
        foreach ($core_font_files as $core_font_file) {
            if (substr($core_font_file, -4) == ".php") {
                include($core_font_file);
                if (in_array($name, array("Symbol", "ZapfDingbats"))) {
                    continue;
                }
                $core_fonts[] = $name;
            }
            elseif (substr($core_font_file, -4) == ".ttf" && strpos($core_font_file, "unifont") > -1) {
                $core_font_file_split = explode("/", $core_font_file);
                
                //these unicode fonts aren't compiled correctly in tFPDF?
                if (strpos($core_font_file_split[count($core_font_file_split)-1], "DejaVuSerif") > -1) {
                    continue;
                }
                
                $core_fonts[] = "(unifont) ".substr_replace($core_font_file_split[count($core_font_file_split)-1], "", -4);
            }
        }
        
        $data["pdf_invoice_plus_fonts"] = array();
        $data["pdf_invoice_plus_fonts"][] = array(
            "name" => "Arial", //Arial is synonymous with Helvetica; sans serif
            "style" => "font-family:Arial; "
        ); 
        
		foreach ($core_fonts as $core_font) {
            $stripped_name = str_ireplace("-BoldOblique", "", $core_font);
            $stripped_name = str_ireplace("-Bold", "", $stripped_name);
            $stripped_name = str_ireplace("-BoldOblique", "", $stripped_name);
            $stripped_name = str_ireplace("-Oblique", "", $stripped_name);
            $stripped_name = str_ireplace("TimesItalic", "Times", $stripped_name);
            $stripped_name = str_ireplace("Times-Italic", "Times", $stripped_name);
            $stripped_name = str_ireplace("Times-Roman", "Times New Roman", $stripped_name);
            $style = "font-family:".$stripped_name."; ";
            if (stripos($core_font, "Bold") > -1) {
                $style .= "font-weight:bold; ";
            }
            if (stripos($core_font, "Oblique") > -1) {
                $style .= "font-style:oblique; ";
            }
            if (stripos($core_font, "Italic") > -1) {
                $style .= "font-style:italic; ";
            }
            $data["pdf_invoice_plus_fonts"][] = array(
                "name" => $core_font,
                "style" => $style." font-size:16px;"
            );
        }
        
        $version_split = explode("_", VERSION);
        if (version_compare($version_split[0], "3.1.0.0") >= 0) {
            $data["bs4"] = true;
        }
        else {
            $data["bs4"] = false;
        }
        
        // end Load core fonts
		
		$this->response->setOutput($this->load->view('extension/module/pdf_invoice_plus/extension', $data));
	}

	public function preview() {
		
		$this->load->model('extension/module/pdf_invoice_plus');

		$this->load->model('sale/order');

		$order_id = 0;

		if (!empty($this->request->get['order_id'])) {
			$order_id = $this->request->get['order_id'];
		} else {
			$order_statuses = $this->config->get('config_complete_status');

			foreach ($order_statuses as $order_status_id) {
				$implode[] = "o.order_status_id = '" . (int)$order_status_id . "'";
			}

			if ($implode) {
				$result = $this->db->query("SELECT o.order_id FROM `" . DB_PREFIX . "order` o WHERE (" . implode(" OR ", $implode) . ") ORDER BY o.order_id DESC LIMIT 1");

				if ($result->row) {
					$order_id = $result->row['order_id'];
				} else {
					// Get any order
					$result = $this->db->query("SELECT o.order_id FROM `" . DB_PREFIX . "order` o ORDER BY o.order_id DESC LIMIT 1");

					if ($result->row) {
						$order_id = $result->row['order_id'];
					} else {
						trigger_error("Warning: requires at least one Complete Order to preview invoice pdf!");
						return false;
					}
				}
			}
		}

		$order_info = $this->model_sale_order->getOrder($order_id);

		if (!$order_info) {
			trigger_error("Warning: unable to find order = '{$order_id}'");
			return false;
		}

		// Overwrite language_id
		if (!empty($this->request->get['language_id'])) {
			$order_info['language_id'] = $this->request->get['language_id'];
		}

		echo $this->model_extension_module_pdf_invoice_plus->getInvoice($order_info, false);
		exit(0);
	}

	public function generate() {
		if (isset($this->request->post['selected'])) {
			$orders = $this->request->post['selected'];
		} elseif (isset($this->request->get['order_id'])) {
			$orders[] = $this->request->get['order_id'];
		}

		if (empty($orders)) { die('select orders first'); }
		
		$this->load->model('extension/module/pdf_invoice_plus');

		echo $this->model_extension_module_pdf_invoice_plus->getInvoice($orders, false);
		exit(0);
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/pdf_invoice_plus')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}