<?php
/**
 * Class ControllerExtensionTfa
 *
 * Two factor authentication extension for Open Cart.
 *
 * @author Gelderblom Internet Solution
 * @copyright 2017-2018 Gelderblom Internet Solutions
 */
class ControllerExtensionTfa extends Controller {
    private $error = array();

    public function index() {

    }
}
